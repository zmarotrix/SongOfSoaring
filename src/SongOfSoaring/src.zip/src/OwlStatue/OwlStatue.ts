import { EventHandler, EventsClient } from 'modloader64_api/EventHandler';
import { IActor, Z64 } from 'Z64Lib/API/imports'
import { IModLoaderAPI, IPlugin } from 'modloader64_api/IModLoaderAPI';
import { IZ64Main } from 'Z64Lib/API/Common/IZ64Main';
import { InjectCore } from 'modloader64_api/CoreInjection';
import { IModelReference, registerModel } from './Z64API';
import { object_sek_optimized } from './object_sek_optimized';
import { number_ref } from 'modloader64_api/Sylvain/ImGui';
import { AgeOrForm, IOvlPayloadResult } from 'Z64Lib/API/Common/Z64API';
import Vector3 from 'modloader64_api/math/Vector3';
import { vec2 } from 'modloader64_api/Sylvain/vec';
import fs from 'fs';
import path from 'path';

interface OwlData {
    id: number;
    scene: number | Array<number>;
    mapLoc: vec2;
    childStatueSpawn: Buffer;
    childStatueRot: Buffer;
    adultStatueSpawn: Buffer;
    adultStatueRot: Buffer;
    isConfigured: Array<boolean>;
}

export default class OwlStatue implements IPlugin {

    ModLoader!: IModLoaderAPI;
    @InjectCore()
    core!: IZ64Main;
    owlModel!: IModelReference;
    id: number_ref = [0];
    owl!: IOvlPayloadResult;
    locations: Array<OwlData> = [];

    preinit(): void {
    }

    init(): void {
    }

    postinit(): void {
        this.locations = JSON.parse(fs.readFileSync(path.resolve(__dirname, "owl.json")).toString());
    }

    onTick(frame?: number): void {
    }

    @EventHandler(EventsClient.ON_PAYLOAD_INJECTED)
    onPayLoad(evt: any) {
        if (evt.file === "OwlStatue.ovl") {
            this.owl = evt.result;
        }
    }

    indexToOffset(i: number): number {
        return 7 - i;
    }

    @EventHandler(Z64.OotEvents.ON_SAVE_LOADED)
    onSaveLoad() {
        this.owlModel = registerModel(object_sek_optimized, true);
        this.owlModel.loadModel();
    }

    spawnOwl(i: number){
        this.owl.spawnActorRXY_Z(this.indexToOffset(this.locations[i].id), this.owlModel.pointer, 0, new Vector3(0, 0, 0)).then((actor: IActor) => {
            if (this.core.OOT!.save.age === AgeOrForm.ADULT) {
                actor.position.setRawPos(this.locations[i].adultStatueSpawn);
                actor.rotation.setRawRot(this.locations[i].adultStatueRot);
            } else {
                actor.position.setRawPos(this.locations[i].childStatueSpawn);
                actor.rotation.setRawRot(this.locations[i].childStatueRot);
            }
        });
    }

    @EventHandler(Z64.OotEvents.ON_SCENE_CHANGE)
    onSceneChange(scene: number) {
        for (let i = 0; i < this.locations.length; i++) {
            if (Array.isArray(this.locations[i].scene)) {
                if (this.locations[i].scene[this.core.OOT!.save.age] === scene) {
                    this.spawnOwl(i)
                    break;
                }
            } else {
                if (this.locations[i].scene === scene) {
                    this.spawnOwl(i)
                    break;
                }
            }
        }
    }
}